<?php
/*
Plugin Name: WP ERP - Recruitment
Plugin URI: http://wperp.com/downloads/recruitment/
Description: Recruitment solution for WP-ERP. Create job posting and hire employee for your company.
Version: 1.2.2
Author: weDevs
Author URI: http://wedevs.com
Text Domain: wp-erp-rec
Domain Path: languages
License: GPL2
*/

/**
 * Copyright (c) YEAR Your Name (email: Email). All rights reserved.
 *
 * Released under the GPL license
 * http://www.opensource.org/licenses/gpl-license.php
 *
 * This is an add-on for WordPress
 * http://wordpress.org/
 *
 * **********************************************************************
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * **********************************************************************
 */

// don't call the file directly
if ( !defined( 'ABSPATH' ) )
    exit;

/**
 * Base_Plugin class
 *
 * @class Base_Plugin The class that holds the entire Base_Plugin plugin
 */
class WeDevs_ERP_Recruitment {

    /**
     * Constructor for the Base_Plugin class
     *
     * Sets up all the appropriate hooks and actions
     * within our plugin.
     *
     * @uses register_activation_hook()
     * @uses register_deactivation_hook()
     * @uses is_admin()
     * @uses add_action()
     */

    /* plugin version
    *
    * @var string
    */
    public $version = '1.2.2';

    /**
     * Load autometically when class initiate
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function __construct() {
        $this->define_constants();

	    require_once WPERP_REC_INCLUDES . '/class-install.php';
        add_action( 'admin_init', [ $this, 'set_role' ] );
        add_action( 'erp_hrm_loaded', array( $this, 'erp_hrm_loaded_hook' ) );
    }

    /**
     * Loaded after hrm module
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function erp_hrm_loaded_hook() {
        $this->includes();

        $this->instantiate();

        $this->actions();

        $this->filters();
    }

    /**
     * Initializes the Base_Plugin() class
     *
     * Checks for an existing Base_Plugin() instance
     * and if it doesn't find one, creates it.
     */
    public static function init() {
        static $instance = false;

        if ( !$instance ) {
            $instance = new WeDevs_ERP_Recruitment();
        }

        return $instance;
    }

    /**
     *  Set role
     *
     * return void
     */
    public function set_role() {
        $users  =   get_users( [ 'role__in' => [ 'administrator', 'erp_hr_manager' ] ] );

        if ( $users ) {
            foreach ( $users as $user ) {
                $user->add_role( 'erp_recruiter' );
            }
        }
    }

    /**
     * check php version is supported
     *
     * @return bool
     */
    public function is_supported_php() {
        if ( version_compare( PHP_VERSION, '5.4.0', '<=' ) ) {
            return false;
        }

        return true;
    }

    /**
     * define the plugin constant
     *
     * @return void
     */
    public function define_constants() {
        define( 'WPERP_REC_VERSION', $this->version );
        define( 'WPERP_REC_FILE', __FILE__ );
        define( 'WPERP_REC_PATH', dirname( WPERP_REC_FILE ) );
        define( 'WPERP_REC_INCLUDES', WPERP_REC_PATH . '/includes' );
        define( 'WPERP_REC_MODULES', WPERP_REC_PATH . '/modules' );
        define( 'WPERP_REC_URL', plugins_url( '', WPERP_REC_FILE ) );
        define( 'WPERP_REC_ASSETS', WPERP_REC_URL . '/assets' );
        define( 'WPERP_REC_VIEWS', WPERP_REC_INCLUDES . '/admin/views' );
        define( 'WPERP_REC_JS_TMPL', WPERP_REC_VIEWS . '/js-templates' );
    }

    /**
     * function objective
     *
     * @return void
     */
    public function includes() {
        if ( !class_exists( 'WP_List_Table' ) ) {
            require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
        }
        require_once WPERP_REC_INCLUDES . '/class-install.php';
        require_once WPERP_REC_INCLUDES . '/class-admin-menu.php';
        require_once WPERP_REC_INCLUDES . '/class-recruitment.php';
        require_once WPERP_REC_INCLUDES . '/class-hr-questionnaire.php';
        require_once WPERP_REC_INCLUDES . '/functions-recruitment.php';
        require_once WPERP_REC_INCLUDES . '/class-rec-ajax.php';
        require_once WPERP_REC_INCLUDES . '/class-form-handler.php';
        require_once WPERP_REC_INCLUDES . '/rec-actions-filters.php';
        require_once WPERP_REC_INCLUDES . '/emails/class-email-new-interview.php';
        require_once WPERP_REC_INCLUDES . '/emails/class-email-new-todo.php';
        require_once WPERP_REC_INCLUDES . '/emails/class-email-opening-report.php';
        require_once WPERP_REC_INCLUDES . '/emails/class-email-candidate-report.php';
        require_once WPERP_REC_INCLUDES . '/class-updates.php';
        require_once WPERP_REC_INCLUDES . '/class-jobseeker-list-table.php';

        if ( !$this->is_supported_php() ) {
            return;
        }
	    // Setup/welcome
	    if ( !empty( $_GET['page'] ) ) {

		    if ( 'erp-recruitment-setup' == $_GET['page'] ) {
			    require_once WPERP_REC_INCLUDES . '/class-setup-wizard.php';
		    }
	    }
	    if ( !class_exists( 'WP_List_Table' ) ) {
		    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
	    }
	    require_once WPERP_REC_INCLUDES . '/class-jobseeker-list-table.php';

	    if ( !$this->is_supported_php() ) {
		    return;
	    }

    }

    /**
     * function objective
     *
     * @return
     */
    public function instantiate() {
        new \WeDevs\ERP\Recruitment\Admin_Menu();
        new \WeDevs\ERP\ERP_Recruitment\Ajax_Handler();
        new \WeDevs\ERP\Recruitment\Updates();

        if ( is_admin() && class_exists( '\WeDevs\ERP\License' ) ) {
            new \WeDevs\ERP\License( __FILE__, 'Recruitment', $this->version, 'weDevs' );
        }
    }

    /**
     * function objective
     *
     * @return
     */
    public function actions() {
        add_action( 'init', [ $this, 'localization_setup' ] );
        add_action( 'init', [ $this, 'erp_rec_register_post_types' ] );
        add_action( 'admin_footer', [ $this, 'admin_rec_js_templates' ] );
        add_action( 'erp_daily_scheduled_events', [ $this, 'erp_rec_email_candidate_list' ] );
        add_action( 'erp_hr_employee_single_tabs', [ $this, 'create_todo_tab' ]);
        add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), [ $this, 'plugin_action_links' ] );
    }

    /**
     * Add action links
     *
     * @param $links
     *
     * @return array
     */
    public function plugin_action_links( $links ) {
        if ( version_compare( WPERP_VERSION, "1.4.0", '>=' ) ) {
            $links[] = '<a href="' . admin_url( 'admin.php?page=erp-hr&section=recruitment&sub-section=job-opening' ) . '">' . __( 'Manage Openings', 'erp-recruitment' ) . '</a>';
        }
        return $links;
    }

    /**
     * Tab of to-do setup
     *
     * @since 1.0.0
     *
     * @return array
     */
    public function create_todo_tab($tabs) {
        if ( current_user_can( 'erp_list_employee' ) ) {
            $tabs['todo'] = [
                'title' => __( 'To-Do', 'wp-erp-rec' ),
                'callback' => [ $this, 'erp_hr_employee_todo_tab' ]
            ];
            return $tabs;
        }
        return $tabs;
    }

    /**
     * To-do view
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function erp_hr_employee_todo_tab() {
        require_once WPERP_REC_VIEWS . '/view-employee-todo.php';
    }

    /**
     * function objective
     *
     * @return void
     */
    public function filters() {
        $this->job_description_filter();
    }

    /**
     * Email candidate list to hiring lead
     *
     * @since 1.1.0
     *
     * @return void
     */
    public function erp_rec_email_candidate_list() {
        //get today's candidate list
        $candidate_list = erp_hr_rec_get_candidate_list();
        if ( count( $candidate_list ) > 0 ) {
            foreach ( $candidate_list as $candidate ) {
                $jobid              = $candidate['job_id'];
                $applicantid        = $candidate['applicant_id'];
                // $hiring_manager_ids = get_post_meta( $jobid, '_hiring_lead', true );
                $job_title          = get_the_title( $jobid );
                $people_info        = erp_get_people( $applicantid );
                $first_name         = $people_info->first_name;
                $last_name          = $people_info->last_name;
                $email              = $people_info->email;
                $subject            = __( 'A new applicant has been applied', 'wp-erp-rec' );
                $message            = sprintf( __( 'Job title : ' . "%s" . '<br />Applicant details:<br />' . 'Name : ' . "%s" . " " . "%s" . '<br />Email : ' . "%s", 'wp-erp-rec' ), $job_title, $first_name, $last_name, $email );
                $headers[]          = "Content-type: text/html";
                // foreach ( $hiring_manager_ids as $hid ) {
                //     $employee_object = new \WeDevs\ERP\HRM\Employee( intval( $hid ) );
                //     wp_mail( $employee_object->user->user_email, $subject, $message, $headers );
                // }
            }
        }
    }

    /**
     * Initialize plugin for localization
     *
     * @uses load_plugin_textdomain()
     */
    public function localization_setup() {
        load_plugin_textdomain( 'wp-erp-rec', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    }

    /**
     * Apply standard WordPress filters on the text
     *
     * @since 1.0.0
     *
     * @return void
     */
    public function job_description_filter() {
        add_filter( 'erp_rec_job_description', 'wptexturize'        );
        add_filter( 'erp_rec_job_description', 'convert_smilies'    );
        add_filter( 'erp_rec_job_description', 'convert_chars'      );
        add_filter( 'erp_rec_job_description', 'wpautop'            );
        add_filter( 'erp_rec_job_description', 'shortcode_unautop'  );
        add_filter( 'erp_rec_job_description', 'prepend_attachment' );

        if ( ! empty( $GLOBALS['wp_embed'] ) ) {
            add_filter( 'erp_rec_job_description', array( $GLOBALS['wp_embed'], 'run_shortcode' ), 8 );
            add_filter( 'erp_rec_job_description', array( $GLOBALS['wp_embed'], 'autoembed' ), 8 );
        }
    }

    /**
     * Register Recruitment post type
     *
     * @since 0.1
     *
     * @return void
     */
    public function erp_rec_register_post_types() {
        $post_type = 'erp_hr_recruitment';
        $capability = 'manage_recruitment';

        register_post_type( $post_type, array(
                'label'           => __( 'Job Openings', 'wp-erp-rec' ),
                'description'     => '',
                'public'          => true,
                'show_ui'         => true,
                'show_in_menu'    => false,
                'capability_type' => 'post',
                'hierarchical'    => false,
                'rewrite'         => array('slug' => 'job'),
                'query_var'       => false,
                'supports'        => array(
                    'title',
                    'editor'
                ),
                'menu_icon'       => 'dashicons-businessman',
                'capabilities'    => array(
                    'edit_post'          => $capability,
                    'read_post'          => $capability,
                    'delete_posts'       => $capability,
                    'edit_posts'         => $capability,
                    'edit_others_posts'  => $capability,
                    'publish_posts'      => $capability,
                    'read_private_posts' => $capability,
                    'create_posts'       => $capability,
                    'delete_post'        => $capability
                ),
                'labels'          => array(
                    'name'               => __( 'Job Openings', 'wp-erp-rec' ),
                    'singular_name'      => __( 'Recruitment', 'wp-erp-rec' ),
                    'menu_name'          => __( 'Recruitment', 'wp-erp-rec' ),
                    'add_new'            => __( 'Create Openings', 'wp-erp-rec' ),
                    'add_new_item'       => __( 'Add New Recruitment', 'wp-erp-rec' ),
                    'edit'               => __( 'Edit', 'wp-erp-rec' ),
                    'edit_item'          => __( 'Edit Openings', 'wp-erp-rec' ),
                    'new_item'           => __( 'New Job Openings', 'wp-erp-rec' ),
                    'view'               => __( 'View Job Openings', 'wp-erp-rec' ),
                    'view_item'          => __( 'View Job Openings', 'wp-erp-rec' ),
                    'search_items'       => __( 'Search Openings', 'wp-erp-rec' ),
                    'not_found'          => __( 'No Job Openings Found', 'wp-erp-rec' ),
                    'not_found_in_trash' => __( 'No Job Openings found in trash', 'wp-erp-rec' ),
                    'parent'             => __( 'Parent Openings', 'wp-erp-rec' )
                )
            )
        );
    }

    /**
     * Print JS templates in footer
     * @since 1.0.0
     * @return void
     */
    public function admin_rec_js_templates() {
        global $current_screen;
        $sub_section    =   isset( $_GET['sub-section'] ) ? $_GET['sub-section'] : '';
        switch ( $sub_section ) {
            case 'todo-calendar':
                erp_get_js_template( WPERP_REC_JS_TMPL . '/todo-template.php', 'erp-rec-todo-template' );
                erp_get_js_template( WPERP_REC_JS_TMPL . '/todo-template-detail.php', 'erp-rec-todo-description-template' );
                break;
            case 'applicant_detail':
                erp_get_js_template( WPERP_REC_JS_TMPL . '/interview-template.php', 'erp-rec-interview-template' );
                erp_get_js_template( WPERP_REC_JS_TMPL . '/todo-template.php', 'erp-rec-todo-template' );
                break;
            default:
                # code...
                break;
        }
        if ( version_compare( WPERP_VERSION , '1.4.0', '<' ) ) {
            switch ( $current_screen->base ) {
                //case 'admin_page_applicant_detail':
                case 'recruitment_page_applicant_detail':
                    erp_get_js_template( WPERP_REC_JS_TMPL . '/todo-template.php', 'erp-rec-todo-template' );
                    erp_get_js_template( WPERP_REC_JS_TMPL . '/interview-template.php', 'erp-rec-interview-template' );
                    break;
                case 'job-openings_page_todo-calendar':
                    erp_get_js_template( WPERP_REC_JS_TMPL . '/todo-template.php', 'erp-rec-todo-template' );
                    break;
                case 'recruitment_page_todo-calendar':
                    erp_get_js_template( WPERP_REC_JS_TMPL . '/todo-template.php', 'erp-rec-todo-template' );
                    erp_get_js_template( WPERP_REC_JS_TMPL . '/todo-template-detail.php', 'erp-rec-todo-description-template' );
                    break;
                case 'recruitment_page_candidate-filter-list':
                    break;
                default:
                    # code...
                    break;
            }
        }
    }

} // Base_Plugin

$WeDevs_ERP_Recruitment = WeDevs_ERP_Recruitment::init();
