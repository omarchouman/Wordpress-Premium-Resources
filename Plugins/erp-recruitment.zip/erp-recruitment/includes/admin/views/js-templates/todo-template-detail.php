<div class="wrap erp">
    <div class="todo-template-container">
        <div class="row">
            <label style="font-weight: bold;"><?php _e('Description', 'wp-erp-rec'); ?></label>
            <span id="todo-description"></span>
        </div>
        <div class="row">
            <label style="font-weight: bold;"><?php _e('Dead Line: ', 'wp-erp-rec'); ?></label>
            <span id="todo-deadline"></span>
        </div>
        <div class="row">
            <label style="font-weight: bold;"><?php _e('Assigned User List: ', 'wp-erp-rec'); ?></label>
            <span id="todo-assigned-user-list"></span>
        </div>
    </div>
</div>
