<?php

/**
 * get the hiring status
 * @return array
 */
function erp_rec_get_hiring_status() {
    $hr_status = array(
        // 'schedule_interview' => __( 'Schedule Interview', 'wp-erp-rec' ),
        // 'put_on_hold'        => __( 'Put on Hold', 'wp-erp-rec' ),
        // 'checking_reference' => __( 'Checking Reference', 'wp-erp-rec' ),
        // 'not_a_fit'          => __( 'Not a Fit', 'wp-erp-rec' ),
        // 'not_qualified'      => __( 'Not Qualified', 'wp-erp-rec' ),
        // 'over_qualified'     => __( 'Over Qualified', 'wp-erp-rec' ),
        // 'archive'            => __( 'Archive', 'wp-erp-rec' ),
        'rejected'           => __( 'Rejected', 'wp-erp-rec' ),
        'withdrawn'          => __( 'Withdrawn', 'wp-erp-rec' ),
        'decline_offer'      => __( 'Declined Offer', 'wp-erp-rec' ),
    );

    return apply_filters( 'erp_hiring_status', $hr_status );
}

/**
 * Get recruitment status drop down
 *
 * @param  int  status id
 * @param  string  selected status
 *
 * @return string the drop down
 */
function erp_hr_get_status_dropdown( $selected = '' ) {
    $status   = erp_rec_get_hiring_status();
    $dropdown = '';

    if ( $status ) {
        foreach ( $status as $key => $title ) {
            $dropdown .= sprintf( "<option value='%s'%s>%s</option>\n", $key, selected( $selected, $key, false ), $title );
        }
    }

    return $dropdown;
}

/**
 * get the minimum experience of recruitment
 *
 * @return array
 */
function erp_rec_get_recruitment_minimum_experience() {
    $min_exp = array(
        'Fresher'        => __( 'Fresher', 'wp-erp-rec' ),
        '1 - 3 Year'     => __( '1 - 3 Year', 'wp-erp-rec' ),
        '3 - 5 Years'    => __( '3 - 5 Years', 'wp-erp-rec' ),
        '5 - 7 Years'    => __( '5 - 7 Years', 'wp-erp-rec' ),
        '7 - 10 Years'   => __( '7 - 10 Years', 'wp-erp-rec' ),
        'Above 10 Years' => __( 'Above 10 Years', 'wp-erp-rec' )
    );

    return apply_filters( 'erp_recruitment_minimum_experience', $min_exp );
}

/**
 * get default fields
 *
 * @return array
 */
function erp_rec_get_default_fields() {

    $default_fields = array(
        'name' => array(
            'label'       => __( 'Name', 'wp-erp-rec' ),
            'type'        => 'name',
            'required'    => true
        ),
        'email'      => array(
            'label'       => __( 'Email', 'wp-erp-rec' ),
            'name'        => 'email',
            'type'        => 'email',
            'placeholder' => __( 'enter email address', 'wp-erp-rec' ),
            'required'    => true
        ),
        'upload_cv'  => array(
            'label'    => __( 'Upload CV', 'wp-erp-rec' ),
            'name'     => 'erp_rec_file', //wpuf_file
            'type'     => 'file',
            'help'     => __( 'only doc, pdf or docx file allowed and file size will be less than 2MB', 'wp-erp-rec' ),
            'required' => true
        )
    );

    return $default_fields;
}

/**
 * get personal fields
 *
 * @return array
 */
function erp_rec_get_personal_fields() {

    $country = \WeDevs\ERP\Countries::instance();

    $personal_fields = array(
        'upload_photo'      => array(
            'label'       => __( 'Upload Photo', 'wp-erp-rec' ),
            'name'        => 'upload_photo',
            'type'        => 'file',
            'placeholder' => '',
            'required'    => false,
            'help'        => __( 'only jpg, jpeg, png image formate allowed and image size will be less than 2MB')
        ),
        'cover_letter'    => array(
            'label'       => __( 'Cover Letter', 'wp-erp-rec' ),
            'name'        => 'cover_letter',
            'type'        => 'textarea',
            'placeholder' => '',
            'required'    => false,
            'help'        => __( 'Why do you think you are a good fit for this job?')
        ),
        'mobile'          => array(
            'label'       => __( 'Mobile', 'wp-erp-rec' ),
            'name'        => 'mobile',
            'type'        => 'text',
            'placeholder' => '',
            'required'    => false
        ),
        'other_email'     => array(
            'label'       => __( 'Other Email', 'wp-erp-rec' ),
            'name'        => 'other_email',
            'type'        => 'email',
            'placeholder' => '',
            'required'    => false
        ),
        'nationality'     => array(
            'label'    => __( 'Nationality', 'wp-erp-rec' ),
            'name'     => 'nationality',
            'type'     => 'select',
            'options'  => $country->countries,
            'required' => false
        ),
        'marital_status'  => array(
            'label'    => __( 'Marital Status', 'wp-erp-rec' ),
            'name'     => 'marital_status',
            'type'     => 'select',
            'options'  => array(
                'single'  => __( 'Single', 'wp-erp-rec' ),
                'married' => __( 'Married', 'wp-erp-rec' ),
                'widowed' => __( 'Widowed', 'wp-erp-rec' )
            ),
            'required' => false
        ),
        'hobbies'         => array(
            'label'       => __( 'Hobbies', 'wp-erp-rec' ),
            'name'        => 'hobbies',
            'type'        => 'textarea',
            'placeholder' => '',
            'required'    => false
        ),
        'address'         => array(
            'label'       => __( 'Address', 'wp-erp-rec' ),
            'name'        => 'address',
            'type'        => 'textarea',
            'placeholder' => '',
            'required'    => false
        ),
        'phone'           => array(
            'label'       => __( 'Phone', 'wp-erp-rec' ),
            'name'        => 'phone',
            'type'        => 'text',
            'placeholder' => '',
            'required'    => false
        ),
        'date_of_birth'   => array(
            'label'       => __( 'Date of Birth', 'wp-erp-rec' ),
            'name'        => 'date_of_birth',
            'type'        => 'date',
            'placeholder' => '',
            'required'    => false
        ),
        'gender'          => array(
            'label'    => __( 'Gender', 'wp-erp-rec' ),
            'name'     => 'gender',
            'type'     => 'select',
            'options'  => array(
                'male'   => __( 'Male', 'wp-erp-rec' ),
                'female' => __( 'Female', 'wp-erp-rec' )
            ),
            'required' => false
        ),
        'driving_license' => array(
            'label'       => __( 'Driving License', 'wp-erp-rec' ),
            'name'        => 'driving_license',
            'type'        => 'text',
            'placeholder' => __( 'enter driving license', 'wp-erp-rec' ),
            'required'    => false
        ),
        'website'         => array(
            'label'       => __( 'Website', 'wp-erp-rec' ),
            'name'        => 'website',
            'type'        => 'text',
            'placeholder' => '',
            'required'    => false
        ),
        'biography'       => array(
            'label'       => __( 'Biography', 'wp-erp-rec' ),
            'name'        => 'biography',
            'type'        => 'textarea',
            'placeholder' => '',
            'required'    => false,
            'help'        => __( 'Let us know a little bit about yourself', 'wp-erp-rec' )
        )
    );

    return apply_filters( 'erp_personal_fields', $personal_fields );
}

/*
 * get count applicants number
 * para custom post id
 * return int
 */
function erp_rec_applicant_counter( $job_id ) {
    global $wpdb;
    if ( $job_id == 0 ) {
        $query = "SELECT COUNT(job_id)
                  FROM {$wpdb->prefix}erp_application as app
                  WHERE app.status=0";
    } else {
        $query = "SELECT COUNT(job_id)
                  FROM {$wpdb->prefix}erp_application as app
                  WHERE app.status=0 AND app.job_id='" . $job_id . "'";
    }

    return $wpdb->get_var( $query );
}

/**
 * Get total number of applicants
 *
 * @since 1.0.0
 *
 * @return int
 */
function erp_rec_get_applicant_counter($job_id) {
    global $wpdb;
    if ( $job_id == 0 ) {
        $query = "SELECT COUNT(job_id)
                  FROM {$wpdb->prefix}erp_application as app
                  LEFT JOIN {$wpdb->prefix}erp_peoplemeta as peoplemeta
                  ON app.applicant_id = peoplemeta.erp_people_id
                  WHERE app.status=0
                  AND peoplemeta.meta_key='status'
                  AND peoplemeta.meta_value='nostatus'";
    } else {
        $query = "SELECT COUNT(job_id)
                  FROM {$wpdb->prefix}erp_application as app
                  LEFT JOIN {$wpdb->prefix}erp_peoplemeta as peoplemeta
                  ON app.applicant_id = peoplemeta.erp_people_id
                  WHERE app.status=0
                  AND app.job_id='" . $job_id . "'
                  AND peoplemeta.meta_key='status'
                  AND peoplemeta.meta_value='nostatus'";
    }

    return $wpdb->get_var( $query );
}

/**
 * Get count all opening number
 *
 *
 *
 * return int
 */
function erp_rec_get_all_count_number() {
    global $wpdb;
    $query = "SELECT ID
              FROM {$wpdb->prefix}posts
              WHERE post_type='erp_hr_recruitment'";
    $res = $wpdb->get_results( $query, ARRAY_A );
    $count_all = 0;
    foreach ( $res as $rdata ) {
        $count_all++;
    }

    return $count_all;
}

/**
 * Get count job expire number
 *
 *
 *
 * return int
 */
function erp_rec_get_expire_count_number() {
    global $wpdb;
    $query = "SELECT ID
              FROM {$wpdb->prefix}posts
              WHERE post_type='erp_hr_recruitment'";
    $res = $wpdb->get_results( $query, ARRAY_A );
    $count_expire = 0;
    foreach ( $res as $rdata ) {
        $e_date = get_post_meta( $rdata['ID'], '_expire_date', true ) ? get_post_meta( $rdata['ID'], '_expire_date', true ) : "N/A";
        if ( 'publish' == get_post_status( $rdata['ID'] ) ) {
            if ( $e_date != "N/A" ) {
                if ( strtotime( date('Y-m-d') ) > strtotime( $e_date ) ) {
                    $count_expire++;
                }
            }
        }
    }

    return $count_expire;
}

/**
 * Get count openings number
 *
 *
 *
 * return int
 */
function erp_rec_get_open_count_number() {
    global $wpdb;
    $query = "SELECT ID
              FROM {$wpdb->prefix}posts
              WHERE post_type='erp_hr_recruitment'";
    $res = $wpdb->get_results( $query, ARRAY_A );
    $count_open = 0;
    foreach ( $res as $rdata ) {
        $e_date = get_post_meta( $rdata['ID'], '_expire_date', true ) ? get_post_meta( $rdata['ID'], '_expire_date', true ) : "N/A";
        if ( 'publish' == get_post_status( $rdata['ID'] ) ) {
            if ( $e_date != "N/A" ) {
                if ( strtotime( date('Y-m-d') ) < strtotime( $e_date ) ) {
                    $count_open++;
                }
            }
        }
    }

    return $count_open;
}

/**
 * Get count openings draft number
 *
 *
 *
 * return int
 */
function erp_rec_get_draft_count_number() {
    global $wpdb;
    $query = "SELECT ID
              FROM {$wpdb->prefix}posts
              WHERE post_type='erp_hr_recruitment'";
    $res = $wpdb->get_results( $query, ARRAY_A );
    $count_draft = 0;
    foreach ( $res as $rdata ) {
        if ( 'draft' == get_post_status( $rdata['ID'] ) ) {
            $count_draft++;
        }
    }

    return $count_draft;
}

/**
 * Get count openings pending number
 *
 *
 *
 * return int
 */
function erp_rec_get_pending_count_number() {
    global $wpdb;
    $query = "SELECT ID
              FROM {$wpdb->prefix}posts
              WHERE post_type='erp_hr_recruitment'";
    $res = $wpdb->get_results( $query, ARRAY_A );
    $count_pending = 0;
    foreach ( $res as $rdata ) {
        if ( 'pending' == get_post_status( $rdata['ID'] ) ) {
            $count_pending++;
        }
    }

    return $count_pending;
}

/*
 * get total applicants number for pagination
 * para args array
 * return int
 */
function erp_rec_total_applicant_counter( $args ) {
    global $wpdb;
    $job_id             = $args['jobid'];
    $offset             = $args['offset'];
    $limit              = isset( $args['limit'] ) ? $args['limit'] : 0;
    $filter_stage       = isset( $args['stage'] ) ? $args['stage'] : 0;
    $filter_added_by_me = isset( $args['added_by_me'] ) ? $args['added_by_me'] : 0;

    $query = "SELECT COUNT(app.applicant_id)
              FROM {$wpdb->prefix}erp_application as app";

    if ( isset( $args['status'] ) ) {
        $query .= " LEFT JOIN {$wpdb->prefix}erp_peoplemeta as peoplemeta
                    ON app.applicant_id = peoplemeta.erp_people_id";
    }

    if ( isset( $args['status'] ) && $args['status'] == 'hired' ) {
        $query .= " WHERE app.status=1";
    } else {
        $query .= " WHERE app.status=0";
    }

    if ( $args['jobid'] != 0 ) {
        $query .= " AND app.job_id='" . $job_id . "'";
    }
    if ( isset( $filter_stage ) && $filter_stage != '' ) { //has stage
        $query .= " AND app.stage='" . $filter_stage . "'";
    }
    if ( isset( $args['status'] ) && $args['status'] == '-1' ) {
        $query .= " AND peoplemeta.meta_key='status'
                    AND peoplemeta.meta_value='nostatus'";
    }
    if ( isset( $args['status'] ) && $args['status'] != '' && $args['status'] != '-1' ) { //has status
        $query .= " AND peoplemeta.meta_key='status' AND peoplemeta.meta_value='" . $args['status'] . "'";
    }
    if ( isset( $filter_added_by_me ) && $filter_added_by_me != '' ) { //has status
        $query .= " AND app.added_by='" . get_current_user_id() . "'";
    }

    return $wpdb->get_var( $query );
}

/*
 * get applicants information
 * para custom post id
 * return array
 */
function erp_rec_get_applicants_information( $args ) {
    global $wpdb;

    $defaults = array(
        'number' => 5,
        'offset' => 0
    );

    $args = wp_parse_args( $args, $defaults );

    $query = "SELECT *,
                     posts.post_title as post_title,
                     base_stage.title as title,
                     application.id as applicationid,
                     people.id as peopleid,
                ( select AVG(rating)
                    FROM {$wpdb->prefix}erp_application_rating
                    WHERE application_id = applicationid ) as avg_rating,
                CONCAT( first_name, ' ', last_name ) as full_name,
                ( select meta_value
                    FROM {$wpdb->prefix}erp_peoplemeta
                    WHERE erp_people_id = peopleid AND meta_key = 'status' ) as status
                FROM {$wpdb->prefix}erp_application as application
                LEFT JOIN {$wpdb->prefix}erp_application_stage as base_stage
                ON application.stage=base_stage.id
                LEFT JOIN {$wpdb->prefix}posts as posts
                ON posts.ID=application.job_id
                LEFT JOIN {$wpdb->prefix}erp_peoplemeta as peoplemeta
                ON application.applicant_id = peoplemeta.erp_people_id
                LEFT JOIN {$wpdb->prefix}erp_application_job_stage_relation as stage
                ON application.job_id=stage.jobid
                LEFT JOIN {$wpdb->prefix}erp_peoples as people
                ON people.id=application.applicant_id";

    if ( isset( $args['status'] ) && $args['status'] == 'hired' ) {
        $query .= " WHERE application.status='1'";
    } else {
        $query .= " WHERE application.status='0'";
    }

    if ( $args['jobid'] != 0 ) {
        $query .= " AND application.job_id='" . $args['jobid'] . "'";
    }
    if ( isset( $args['stage'] ) && $args['stage'] != '' ) { //has stage
        $query .= " AND application.stage='" . $args['stage'] . "'";
    }
    if ( isset( $args['status'] ) && $args['status'] == '-1' ) {
        $query .= " AND peoplemeta.meta_key='status'
                    AND peoplemeta.meta_value='nostatus'";
    }

    if ( isset( $args['status'] ) && $args['status'] != '' && $args['status'] != '-1' ) { //has status
        $query .= " AND peoplemeta.meta_key='status' AND peoplemeta.meta_value='" . $args['status'] . "'";
    }

    if ( isset( $args['added_by_me'] ) && $args['added_by_me'] != '' ) { //added by me query
        $query .= " AND application.added_by='" . get_current_user_id() . "'";
    }
    if ( isset( $args['search_key'] ) && $args['search_key'] != '' ) { //search is not empty
        $query .= " AND people.first_name LIKE '%" . $args['search_key'] . "%' OR people.last_name LIKE '%" . $args['search_key'] . "%'";
    }

    if ( isset( $args['orderby'] ) ) {
        $query .= " GROUP BY applicationid ORDER BY " . $args['orderby'] . " " . $args['order'] . " LIMIT {$args['offset']}, {$args['number']}";
    } else {
        $query .= " GROUP BY applicationid ORDER BY application.apply_date DESC LIMIT {$args['offset']}, {$args['number']}";
    }

    return $wpdb->get_results( $query, ARRAY_A );
}

/*
 * get total job opening number for pagination
 * para args array
 * return int
 */
function erp_rec_total_opening_counter( $args ) {
    global $wpdb;
    $job_id             = $args['jobid'];
    $offset             = $args['offset'];
    $limit              = isset( $args['limit'] ) ? $args['limit'] : 0;
    $query = "SELECT COUNT(post.id)
              FROM {$wpdb->prefix}posts as post
              INNER JOIN {$wpdb->prefix}postmeta as pmeta
              ON pmeta.post_id=post.id
              WHERE post.post_type='erp_hr_recruitment'
              AND pmeta.meta_key='_expire_date'";

    if ( isset( $args['status'] ) && $args['status'] != '' && $args['status'] != '-1' && ( $args['status'] == 'draft' || $args['status'] == 'pending' ) ) { //has status
        $query .= " AND post.post_status='" . $args['status'] . "'";
    }
    if ( isset( $args['status'] ) && $args['status'] == 'publish' && $args['status'] != '' && $args['status'] != '-1' ) {
        $query .= " AND post.post_status='publish' AND DATE(pmeta.meta_value) > CURDATE()";
    }
    if ( isset( $args['status'] ) && $args['status'] == 'expired' && $args['status'] != '' && $args['status'] != '-1' ) {
        $query .= " AND post.post_status='publish' AND DATE(pmeta.meta_value) < CURDATE()";
    }

    return $wpdb->get_var( $query );
}

/*
 * get applicants information
 * para custom post id
 * return array
 */
function erp_rec_get_opening_information( $args ) {
    global $wpdb;

    $defaults = array(
        'number' => 5,
        'offset' => 0
    );

    $args = wp_parse_args( $args, $defaults );

    $query = "SELECT DISTINCT post.post_title as job_title,
                     post.id as id,
                     post.post_date as created_on,
                     post.post_status as post_status,
                     pmeta.meta_value as edate
                     FROM {$wpdb->prefix}posts as post
                     INNER JOIN {$wpdb->prefix}postmeta as pmeta
                     ON pmeta.post_id=post.id
                     WHERE post.post_type='erp_hr_recruitment'
                     AND pmeta.meta_key='_expire_date'";

    if ( isset( $args['status'] ) && $args['status'] != '' && $args['status'] != '-1' && ( $args['status'] == 'draft' || $args['status'] == 'pending' ) ) { //has status
        $query .= " AND post.post_status='" . $args['status'] . "'";
    }
    if ( isset( $args['status'] ) && $args['status'] == 'publish' && $args['status'] != '' && $args['status'] != '-1' ) {
        $query .= " AND post.post_status='publish' AND DATE(pmeta.meta_value) > CURDATE()";
    }
    if ( isset( $args['status'] ) && $args['status'] == 'expired' && $args['status'] != '' && $args['status'] != '-1' ) {
        $query .= " AND post.post_status='publish' AND DATE(pmeta.meta_value) < CURDATE()";
    }
    if ( isset( $args['search_key'] ) && $args['search_key'] != '' ) { //search is not empty
        $query .= " AND post.post_title LIKE '%" . $args['search_key'] . "%'";
    }

    if ( isset( $args['orderby'] ) ) {
        $query .= " ORDER BY " . $args['orderby'] . " " . $args['order'] . " LIMIT {$args['offset']}, {$args['number']}";
    } else {
        $query .= " ORDER BY id DESC LIMIT {$args['offset']}, {$args['number']}";
    }

    return $wpdb->get_results( $query, ARRAY_A );
}

/*
 * get applicant information
 * para custom post id, applicant id
 * return array
 */
function erp_rec_get_applicant_information( $application_id ) {
    global $wpdb;

    $query = "SELECT *
                FROM {$wpdb->prefix}erp_peoples as people
                LEFT JOIN {$wpdb->prefix}erp_application as app
                ON people.id = app.applicant_id
                WHERE app.id=%d";
    return $wpdb->get_results( $wpdb->prepare( $query, $application_id ), ARRAY_A );
}

/**
 * Get total applicants in a specific job
 *
 * @since 1.1.0
 *
 * @return int
 */
function get_applicants_counter($jobid) {
    global $wpdb;

    $query = "SELECT COUNT(applicant_id)
              FROM {$wpdb->prefix}erp_application
              WHERE job_id=%d AND status=0";
    $res = $wpdb->get_var( $wpdb->prepare( $query, $jobid ) );
    if ( $res != null ) {
        return $res;
    } else {
        return 0;
    }
}

/*
* get applicant information
* para custom post id, applicant id
* return array
*/
function erp_rec_get_applicant_single_information( $applicant_id, $meta_key ) {
    global $wpdb;

    $query = "SELECT meta_value
                FROM {$wpdb->prefix}erp_peoplemeta as peoplemeta
                WHERE peoplemeta.meta_key='%s'
                AND peoplemeta.erp_people_id=%s";
    return $wpdb->get_var( $wpdb->prepare( $query, $meta_key, $applicant_id ) );
}

/*
* get comment of specific applicant of specific job
* para application id, applicant id
* return array
*/
function erp_rec_get_application_comments( $application_id ) {
    global $wpdb;

    $query = "SELECT *
                FROM {$wpdb->prefix}erp_application_comment as comment
                LEFT JOIN {$wpdb->prefix}users as user
                ON comment.admin_user_id = user.ID
                WHERE comment.application_id='" . $application_id . "'";
    return $wpdb->get_results( $query, ARRAY_A );
}

/*
 * function get application stage
 * para int
 * return array
 */
function erp_rec_get_application_stage_intvw_popup( $application_id ) {
    global $wpdb;
    $query    = "SELECT stage.stageid, base_stage.title
                FROM {$wpdb->prefix}erp_application_job_stage_relation as stage
                LEFT JOIN {$wpdb->prefix}erp_application as application
                ON stage.jobid=application.job_id
                LEFT JOIN {$wpdb->prefix}erp_application_stage as base_stage
                ON stage.stageid=base_stage.id
                WHERE application.id='%d'
                ORDER BY base_stage.id";
    $stages   = $wpdb->get_results( $wpdb->prepare( $query, $application_id ), ARRAY_A );
    $dropdown = array( 0 => __( '- Select Stage -', 'wp-erp-rec' ) );
    if ( count( $stages ) > 0 ) {
        foreach ( $stages as $value ) {
            $dropdown[$value['stageid']] = $value['title'];
        }
    }
    return $dropdown;
}

/*
 * function get app stage
 * para int
 * return array
 */
function erp_rec_get_app_stage( $application_id ) {
    global $wpdb;
    $query = "SELECT base_stage.title
                FROM {$wpdb->prefix}erp_application as app
                LEFT JOIN {$wpdb->prefix}erp_application_stage as base_stage
                ON app.stage=base_stage.id
                WHERE app.id='%d'";
    return $wpdb->get_var( $wpdb->prepare( $query, $application_id ) );
}

/**
 * get the minimum experience of recruitment
 *
 * @return array
 */
function erp_rec_get_interview_time_duration() {
    $interview_time_duration = array(
        '15'  => __( '15 minutes', 'wp-erp-rec' ),
        '30'  => __( '30 minutes', 'wp-erp-rec' ),
        '45'  => __( '45 minutes', 'wp-erp-rec' ),
        '60'  => __( '1 hour', 'wp-erp-rec' ),
        '105' => __( '1 hour 30 minutes', 'wp-erp-rec' ),
        '120' => __( '2 hours', 'wp-erp-rec' )
    );

    return apply_filters( 'interview_time_duration', $interview_time_duration );
}

/*
* check email is duplicate or not
* para email as string, job id as int
* return bool
*/
function erp_rec_is_duplicate_email( $email, $job_id ) {
    global $wpdb;

    $query = "SELECT email
                FROM {$wpdb->prefix}erp_peoples as people
                LEFT JOIN {$wpdb->prefix}erp_application as application
                ON people.id = application.applicant_id
                WHERE people.email='%s' AND application.job_id=%d";

    if ( count( $wpdb->get_results( $wpdb->prepare( $query, $email, $job_id ), ARRAY_A ) ) > 0 ) {
        return true;
    } else {
        return false;
    }
}

/*
* check rating done or not
* para int application id , int admin user id
* return bool
*/
function erp_rec_has_rating( $application_id, $admin_user_id ) {
    global $wpdb;
    $query = "SELECT id
                FROM {$wpdb->prefix}erp_application_rating
                WHERE application_id='%d' AND user_id='%d'";

    if ( count( $wpdb->get_results( $wpdb->prepare( $query, $application_id, $admin_user_id ), ARRAY_A ) ) > 0 ) {
        return true;
    } else {
        return false;
    }
}

/*
* check this stage has candidate or not
* para int job id
* return bool
*/
function erp_rec_has_candidate( $job_id, $stage_title ) {
    global $wpdb;
    $query = "SELECT app.id
                FROM {$wpdb->prefix}erp_application as app
                WHERE app.job_id='%d'
                AND app.stage='%s'";

    if ( count( $wpdb->get_results( $wpdb->prepare( $query, $job_id, $stage_title ), ARRAY_A ) ) > 0 ) {
        return true;
    } else {
        return false;
    }
}

/*
* check this job has stage or not
* para int job id
* return bool
*/
function erp_rec_count_stage( $job_id ) {
    global $wpdb;
    $query = "SELECT stage.id
                FROM {$wpdb->prefix}erp_application_job_stage_relation as stage
                WHERE stage.jobid='%d'";

    return count( $wpdb->get_results( $wpdb->prepare( $query, $job_id ), ARRAY_A ) );
}

/* check rating done or not
* para int application id , int admin user id
* return bool
*/
function erp_rec_has_status( $applicant_id ) {
    global $wpdb;
    $meta_key = 'status';
    $query    = "SELECT meta_id
        FROM {$wpdb->prefix}erp_peoplemeta
        WHERE meta_key='%s' AND erp_people_id='%d'";

    if ( count( $wpdb->get_results( $wpdb->prepare( $query, $meta_key, $applicant_id ), ARRAY_A ) ) > 0 ) {
        return true;
    } else {
        return false;
    }
}

/* check duplicate stage name or not
* para int stage title
* return bool
*/
function erp_rec_check_duplicate_stage( $stage_title ) {
    global $wpdb;
    $query = "SELECT id FROM {$wpdb->prefix}erp_application_stage WHERE title='%s'";

    if ( count( $wpdb->get_results( $wpdb->prepare( $query, $stage_title ), ARRAY_A ) ) > 0 ) {
        return true;
    } else {
        return false;
    }
}

/*
* update people table that now that people is an employee
* para employee id
* return void
*/
function erp_rec_update_people_data( $employee_id, $email, $applicant_id ) {
    global $wpdb;
    // update application table
    $data         = array(
        'status' => 1
    );
    $where        = array(
        'applicant_id' => $applicant_id
    );
    $data_format  = array(
        '%d'
    );
    $where_format = array(
        '%d'
    );
    $wpdb->update( $wpdb->prefix . 'erp_application', $data, $where, $data_format, $where_format );

    return true;
}

/*
* file uploader
* para file array
* return array
*/
function erp_rec_handle_upload( $upload_data ) {

    $uploaded_file = wp_handle_upload( $upload_data, array( 'test_form' => false ) );
    // If the wp_handle_upload call returned a local path for the image
    if ( isset( $uploaded_file['file'] ) ) {
        $file_loc    = $uploaded_file['file'];
        $file_name   = basename( $upload_data['name'] );
        $file_type   = wp_check_filetype( $file_name );
        $attachment  = array(
            'post_mime_type' => $file_type['type'],
            'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $file_name ) ),
            'post_content'   => '',
            'post_status'    => 'inherit'
        );
        $attach_id   = wp_insert_attachment( $attachment, $file_loc );
        $attach_data = wp_generate_attachment_metadata( $attach_id, $file_loc );
        wp_update_attachment_metadata( $attach_id, $attach_data );
        return array( 'success' => true, 'attach_id' => $attach_id );
    }
    return array( 'success' => false, 'error' => $uploaded_file['error'] );
}

/**
 * get the hiring stages
 * @return array
 */
function erp_rec_get_hiring_stages() {
    $hr_stages = array(
        'Screening'              => __( 'Screening', 'wp-erp-rec' ),
        'Phone Interview'        => __( 'Interview', 'wp-erp-rec' ),
        'Face to Face Interview' => __( 'Face to Face Interview', 'wp-erp-rec' ),
        'Made an Offer'          => __( 'Made an Offer', 'wp-erp-rec' )
    );

    return apply_filters( 'erp_hiring_stages', $hr_stages );
}

/*
 * get stage id and title of specific applicant of specific job
 * para application id, applicant id
 * return array
 */
function erp_rec_get_application_stages( $application_id ) {
    global $wpdb;

    $query = "SELECT stage.stageid, base_stage.title
                FROM {$wpdb->prefix}erp_application_job_stage_relation as stage
                LEFT JOIN {$wpdb->prefix}erp_application as application
                ON stage.jobid = application.job_id
                LEFT JOIN {$wpdb->prefix}erp_application_stage as base_stage
                ON base_stage.id = stage.stageid
                WHERE application.id=%d";
    return $wpdb->get_results( $wpdb->prepare( $query, $application_id ), ARRAY_A );
}

/*
 * get stage id and title of specific job
 * para job id
 * return array
 */
function erp_rec_get_this_job_stages( $job_id ) {
    global $wpdb;

    $query = "SELECT stage.stageid, base_stage.title
                FROM {$wpdb->prefix}erp_application_job_stage_relation as stage
                LEFT JOIN {$wpdb->prefix}erp_application_stage as base_stage
                ON stage.stageid=base_stage.id
                WHERE stage.jobid=%d";
    return $wpdb->get_results( $wpdb->prepare( $query, $job_id ), ARRAY_A );
}

/*
 * get stage id and title of all jobs
 * para
 * return array
 */
function erp_rec_get_all_stages() {
    global $wpdb;
    $query = "SELECT stage.id, stage.title
                FROM {$wpdb->prefix}erp_application_stage as stage
                ORDER BY stage.title";
    return $wpdb->get_results( $query, ARRAY_A );
}

/*
 * get candidate number in this stage
 * para job id, stage title
 * return array
 */
function erp_rec_get_candidate_number_in_this_stages( $job_id, $stage_id ) {
    global $wpdb;

    if ( $job_id == 0 ) {
        $query = "SELECT COUNT(app.id)
                  FROM {$wpdb->prefix}erp_application as app
                  LEFT JOIN {$wpdb->prefix}erp_peoplemeta as peoplemeta
                  ON app.applicant_id = peoplemeta.erp_people_id
                  WHERE app.status=0
                  AND app.stage='%d'
                  AND peoplemeta.meta_key='status'
                  AND peoplemeta.meta_value='nostatus'";
        return $wpdb->get_var( $wpdb->prepare( $query, $stage_id ) );
    } else {
        $query = "SELECT COUNT(app.id)
                  FROM {$wpdb->prefix}erp_application as app
                  LEFT JOIN {$wpdb->prefix}erp_peoplemeta as peoplemeta
                  ON app.applicant_id = peoplemeta.erp_people_id
                  WHERE app.job_id='%d'
                  AND app.stage='%d'
                  AND app.status=0
                  AND peoplemeta.meta_key='status'
                  AND peoplemeta.meta_value='nostatus'";
        return $wpdb->get_var( $wpdb->prepare( $query, $job_id, $stage_id ) );
    }

}

/*
 * get all jobs
 * para
 * return array
 */
function erp_rec_get_all_jobs() {
    $type     = 'erp_hr_recruitment';
    $args     = array(
        'post_type'      => $type,
        'post_status'    => 'publish',
        'posts_per_page' => -1
    );
    $jobs     = [ ];
    $my_query = null;
    $my_query = new WP_Query( $args );
    if ( $my_query->have_posts() ) {
        while ( $my_query->have_posts() ) {
            $my_query->the_post();
            $jobs[] = [ 'jobid' => get_the_ID(), 'jobtitle' => get_the_title() ];
        }
    }
    wp_reset_query();  // Restore global post data stomped by the_post()
    return $jobs;
}

/*
 * get stage
 * para
 * return array
 */
function erp_rec_get_stage( $jobid ) {
    global $wpdb;
    if ( isset( $jobid ) ) {
        $query       = "SELECT COUNT(id) FROM {$wpdb->prefix}erp_application_job_stage_relation WHERE jobid=%d";
        $row_counter = $wpdb->get_var( $wpdb->prepare( $query, $jobid ) );
        if ( $row_counter > 0 ) {
            $query = "SELECT stage.id as sid,stage.title,
                          ( SELECT stageid
                            FROM {$wpdb->prefix}erp_application_job_stage_relation
                            WHERE jobid={$jobid} AND stageid=sid ) as stage_selected,
                          ( SELECT COUNT(id)
                            FROM {$wpdb->prefix}erp_application
                            WHERE job_id={$jobid} AND stage=sid ) as candidate_number
                          FROM {$wpdb->prefix}erp_application_stage as stage ORDER BY stage.id";
            return $wpdb->get_results( $query, ARRAY_A );
        } else {
            $query = "SELECT stage.id as sid, stage.title
                FROM {$wpdb->prefix}erp_application_stage as stage
                LEFT JOIN {$wpdb->prefix}users as user
                ON stage.created_by = user.ID";

            return $wpdb->get_results( $query, ARRAY_A );
        }
    } else {
        return false;
    }
}

/*
 * get stages in creating recruitment
 * para
 * return array
 */
function erp_rec_get_stages( $jobid ) {
    global $wpdb;
    if ( isset( $jobid ) ) {
        $query      = "SELECT stage.id as sid, stage.title as title FROM {$wpdb->prefix}erp_application_stage as stage ORDER BY sid";
        $stages     = $wpdb->get_results( $query, ARRAY_A );

        $query  = "SELECT st_rel.stageid as sid, stage.title as title
                  FROM {$wpdb->prefix}erp_application_stage as stage
                  LEFT JOIN {$wpdb->prefix}erp_application_job_stage_relation as st_rel
                  ON stage.id=st_rel.stageid
                  WHERE st_rel.jobid=%d
                  ORDER BY sid";
        $st_rel = $wpdb->get_results( $wpdb->prepare( $query, $jobid ), ARRAY_A );

        $final_selected_stage = [ ];
        foreach ( $stages as $stage_value ) {
            $got_stage_id = erp_rec_searchForId( $stage_value['sid'], $st_rel );
            if ( $got_stage_id ) {
                $final_selected_stage[] = [
                    'sid'      => $stage_value['sid'],
                    'title'    => $stage_value['title'],
                    'selected' => true
                ];
            } else {
                $final_selected_stage[] = [
                    'sid'      => $stage_value['sid'],
                    'title'    => $stage_value['title'],
                    'selected' => false
                ];
            }
        }

        return $final_selected_stage;

    } else {
        return false;
    }
}

/*
 * search id in an array
 *
 * @return mixed
 */
function erp_rec_searchForId( $sid, $array ) {
    foreach ( $array as $key => $val ) {
        if ( $val['sid'] === $sid ) {
            return $sid;
        }
    }
    return false;
}

/*
 * update stage on update recruitment post
 * para post id int
 * return mix
 */

function erp_rec_update_stage( $selected_stages, $jobid ) {

    global $wpdb;
    // first delete all stage in this job id
    $where  = array(
        'jobid' => $jobid
    );
    $format = array(
        '%d'
    );
    $wpdb->delete( $wpdb->prefix . 'erp_application_job_stage_relation', $where, $format );
    // now insert stage id to this job id
    foreach ( $selected_stages as $stdata ) {
        $sql = "INSERT INTO {$wpdb->prefix}erp_application_job_stage_relation(jobid,stageid) VALUES('%d','%d')";
        $wpdb->query( $wpdb->prepare( $sql, $jobid, $stdata ) );
    }
}


/*
 * show admin notice
 * para
 * return void
 */
function erp_rec_show_notice() {
    if ( isset( $_REQUEST['page'] ) == 'erp-hr-employee' && isset( $_REQUEST['action'] ) == 'view' && isset( $_REQUEST['id'] ) ) {
        if ( $_REQUEST['page'] == 'erp-hr-employee' && $_REQUEST['action'] == 'view' && is_numeric( $_REQUEST['id'] ) && $_REQUEST['id'] > 0 && isset( $_REQUEST['message'] ) ) {
            if ( $_REQUEST['message'] == 1 ) { ?>
                <div class="notice notice-success is-dismissible">
                <p><?php _e( 'Congrats! New employee has been created successfully', 'wp-erp-rec' ); ?></p>
                </div><?php }
        }
    }
}

/**
 * show admin notice post error during edit in job opening
 *
 * @return void
 */
function erp_rec_show_post_error_notice() {

}

/**
 * Get applicant id by job id
 *
 * @since 1.0.2
 *
 * @return array
 */
function erp_rec_get_applicant_id($jobid) {
    global $wpdb;
    $query = "SELECT applicant_id
              FROM {$wpdb->prefix}erp_application
              WHERE job_id='%d'";
    return $wpdb->get_results( $wpdb->prepare( $query, $jobid ), ARRAY_A );
}

/**
 * Get applicant id by job id
 *
 * @since 1.0.2
 *
 * @return array
 */
function erp_rec_get_all_applicant_id() {
    global $wpdb;
    $query = "SELECT applicant_id
              FROM {$wpdb->prefix}erp_application";
    return $wpdb->get_results( $query, ARRAY_A );
}

/**
 * Remove job opening
 *
 * @since 1.0.0
 *
 * @return void
 */
function delete_candidate_info( $jobid ) {
    global $wpdb;
    wp_delete_post($jobid);
    $query = "SELECT id as appid, applicant_id
                FROM {$wpdb->prefix}erp_application as app
                WHERE app.job_id='" . $jobid . "'";
    $udata = $wpdb->get_results( $query, ARRAY_A );
    foreach ( $udata as $peoplemetadata ) {
        $wpdb->delete( $wpdb->prefix . 'erp_peoples', array( 'id' => $peoplemetadata['applicant_id'] ), array( '%d' ) );
        $wpdb->delete( $wpdb->prefix . 'erp_peoplemeta', array( 'erp_people_id' => $peoplemetadata['applicant_id'] ), array( '%d' ) );
        $wpdb->delete( $wpdb->prefix . 'erp_application_rating', array( 'application_id' => $peoplemetadata['appid'] ), array( '%d' ) );
    }
    $wpdb->delete( $wpdb->prefix . 'erp_application', array( 'job_id' => $jobid ), array( '%d' ) );
    $wpdb->delete( $wpdb->prefix . 'erp_application_job_stage_relation', array( 'jobid' => $jobid ), array( '%d' ) );
}

/**
 * Show admin progressbar
 *
 * @since 1.0.0
 *
 * @return mixed
 */
function erp_rec_opening_admin_progressbar( $selected ) {
    $steps = array(
        'job_description'             => __( 'Job description', 'wp-erp-rec' ),
        'hiring_workflow'             => __( 'Hiring workflow', 'wp-erp-rec' ),
        'job_information'             => __( 'Job information', 'wp-erp-rec' ),
        'candidate_basic_information' => __( 'Basic information', 'wp-erp-rec' ),
        'questionnaire_selection'     => __( 'Question set', 'wp-erp-rec' ),
    );

    $step_counter = 1;
    $html         = '';
    $html .= '<ul class="recruitment-step-progress">';
    foreach ( $steps as $key => $value ) {
        $html .= sprintf( '<li class="%s"><span class="step-number">%d</span><span class="step-content">%s</span></li>', ( $key == $selected ) ? 'active' : 'not-active', $step_counter, $value );
        $step_counter++;
    }

    $html .= '</ul>';

    return $html;
}

/**
 * Get candidate list of today
 *
 * @since 1.1.0
 *
 * @return array
 */
function erp_hr_rec_get_candidate_list() {
    global $wpdb;

    $query = "SELECT applicant_id, job_id
              FROM {$wpdb->prefix}erp_application
              WHERE DATE(apply_date)=CURDATE()";
    $res = $wpdb->get_results( $query, ARRAY_A );
    if ( count($res) > 0 ) {
        return $res;
    } else {
        return [];
    }
}

/**
 * Get current user to-do
 *
 * @since 1.1.0
 *
 * @return array
 */
function get_todos() {
    global $wpdb;
    $user_id = ( isset( $_GET['id'] ) ) ? $_GET['id'] : get_current_user_id();

    $query = "SELECT todo.title,
                     todo.deadline_date,
                     todo.created_at,
                     user.display_name
              FROM {$wpdb->prefix}erp_application_todo as todo
              LEFT JOIN {$wpdb->prefix}erp_application_todo_relation as rtodo
              ON todo.id=rtodo.todo_id
              LEFT JOIN {$wpdb->prefix}users as user
              ON todo.created_by=user.id
              WHERE rtodo.assigned_user_id=%d AND
              todo.status=0";
    $res = $wpdb->get_results( $wpdb->prepare( $query, $user_id ), ARRAY_A );
    if ( count($res) > 0 ) {
        return $res;
    } else {
        return [];
    }
}

/**
 * Delete candidate
 *
 * @since 1.1.0
 *
 * @return void
 */
function delete_candidate($jobseekeremail) {
    global $wpdb;
    //get job seeker id
    $query = "SELECT id
              FROM {$wpdb->prefix}erp_peoples
              WHERE email=%s";
    $jobseekerid = $wpdb->get_var( $wpdb->prepare( $query, $jobseekeremail ) );

    $wpdb->delete( $wpdb->prefix . 'erp_peoples', [ 'id' => $jobseekerid ], ['%d'] );
    $wpdb->delete( $wpdb->prefix . 'erp_peoplemeta', [ 'erp_people_id' => $jobseekerid ], ['%d'] );
    $wpdb->delete( $wpdb->prefix . 'erp_application', [ 'applicant_id' => $jobseekerid ], ['%d'] );
}

/**
 * Create recruitment url
 *
 * @param  string $slug Recruitment URL
 * @return string
 */
function erp_rec_url( $slug = '' ) {
    if ( version_compare( WPERP_VERSION, '1.4.0', '<' ) ) {
        return admin_url( 'admin.php?page=' . $slug );
    }

    if ( empty( $slug ) ) {
        return admin_url( 'admin.php?page=erp-hr&section=recruitment' );
    }

    return admin_url( 'admin.php?page=erp-hr&section=recruitment&sub-section=' . $slug );
}


/** =========================================
 * Recruiter role related functionality
 * ==========================================
 */


/**
 * Add erp_recruiter role
 *
 * @param array $roles
 *
 * @return array
 */
function erp_rec_recruiter_role_to_hr_roles( $roles ) {
    $roles['erp_recruiter'] = [
        'name'         => __( 'Recruiter', 'erp' ),
        'public'       => false,
        'capabilities' => [ 'manage_recruitment' => true ]
    ];

    return $roles;
}

/**
 * Map recruitment meta cap
 *
 * @param array   $caps
 * @param string  $cap
 * @param integer $user_id
 * @param mixed   $args
 *
 * @return array
 */
function erp_rec_map_meta_cap( $caps, $cap, $user_id, $args ) {
    if ( 'manage_recruitment' === $cap ) {
        if ( user_can( $user_id, 'manage_options' ) || user_can( $user_id, erp_hr_get_manager_role() ) ) {
            $caps = [ $cap ];
        } else {
            $caps = [ 'do_not_allow' ];
        }
    }

    return $caps;
}

/**
 * User profile recruiter role checkbox
 *
 * @param object $profile_user
 *
 * @return void
 */
function erp_rec_user_profile_role( $profile_user ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $checked = in_array( 'erp_recruiter', $profile_user->roles ) ? 'checked' : '';
    ?>

    <label for="erp-recruiter">
        <input type="checkbox" id="erp-recruiter" <?php echo $checked; ?> name="erp_recruiter" value="erp_recruiter">
        <span class="description"><?php _e( 'Recruiter', 'erp' ); ?></span>
    </label>

    <?php
}

/**
 * Employee permission tab recruiter role
 *
 * @param object $user
 *
 * @return void
 */
function erp_rec_recruiter_role_in_permission( $user ) {
    if ( ! current_user_can( erp_hr_get_manager_role() ) ) {
        return;
    }

    $is_recruiter = user_can( $user->ID, 'erp_recruiter' ) ? 'on' : 'off';

    erp_html_form_input( array(
        'label' => __( 'Recruiter', 'erp' ),
        'name'  => 'erp_recruiter',
        'type'  => 'checkbox',
        'tag'   => 'div',
        'value' => $is_recruiter,
        'help'  => __( 'This Employee is Recruiter', 'erp'  )
    ) );
}

/**
 * Set employee permission tab recruiter role after update
 *
 * @param object $post
 *
 * @param object $user
 *
 * @return void
 */
function erp_rec_recruiter_role_permission_set( $post, $user ) {
    $enable_recruiter   = ! empty( $post['erp_recruiter'] ) ? filter_var( $post['erp_recruiter'], FILTER_VALIDATE_BOOLEAN ) : false;
    $erp_recruiter_role = 'erp_recruiter';

    if ( current_user_can( erp_hr_get_manager_role() ) ) {
        if ( $enable_recruiter ) {
            $user->add_role( $erp_recruiter_role );
        } else {
            $user->remove_role( $erp_recruiter_role );
        }
    }
}

/**
 * Update user role
 *
 * @param integer $user_id
 *
 * @param object $post
 *
 * @return void
 */
function erp_rec_update_user( $user_id, $post ) {
    $new_erp_recruiter_role = ! empty( $post['erp_recruiter'] ) ? sanitize_text_field( $post['erp_recruiter'] ) : false;

    if ( ! $new_erp_recruiter_role ) {
        return;
    }

    if ( ! current_user_can( 'promote_user', $user_id ) ) {
        return;
    }

    $user = get_user_by( 'id', $user_id );

    if ( $new_erp_recruiter_role ) {
        $user->add_role( 'erp_recruiter' );
    } else {
        $user->remove_role( 'erp_recruiter' );
    }
}
