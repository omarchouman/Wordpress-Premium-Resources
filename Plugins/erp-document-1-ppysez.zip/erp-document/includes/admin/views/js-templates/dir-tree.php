<h1><?php _e('Move folder to...','wp-erp-doc');?></h1>
<div id="evts" class="demo"></div>

<div class="css-treeview">
    <ul class="root-tree">
        <li>
            <input class="itid" type="checkbox" id="0" checked="checked" />
            <label class="tid"><?php _e('Home','wp-erp-doc');?></label>
            <ul class="root-main-thing">

            </ul>
        </li>
    </ul>
</div>