<?php
/**
 * Woostify Ajax Product function
 *
 * @package  Woostify Pro
 */

if ( get_template_directory() !== get_stylesheet_directory() && file_exists( get_stylesheet_directory() . '/custom-query.php' ) ) {
	require get_stylesheet_directory() . '/custom-query.php';
}
