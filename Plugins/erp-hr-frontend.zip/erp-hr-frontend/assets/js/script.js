var $ = window.jQuery;

/* Sidebar Menu Toggle */

var menuBar = null,
    menuList = null,
    contentSection = null;

function onResize() {
    menuList.removeClass('has-text-centered');

    if (window.innerWidth < 1300 && window.innerWidth > 768) {
        menuBar.addClass('slide');
        contentSection.removeClass('is-10').addClass('is-12');
    } else if (window.innerWidth < 768) {
        menuBar.removeClass('slide');
    }
}

$('body').on('click', '.toggler', function() {
    if (menuBar.hasClass('slide')) {
        menuBar.removeClass('slide');
        contentSection.removeClass('is-12').addClass('is-10');
    } else {
        menuBar.addClass('slide');
        contentSection.removeClass('is-10').addClass('is-12');
    }
});

$(window).on('load', function() {
    setTimeout(function() {

        menuBar = $('.menu-bar');
        menuList = $('.menu-list');
        contentSection = $('.content-section');

        onResize();
        window.addEventListener('resize', onResize);

    }, 2000);
});
