<?php
namespace WeDevs\ERP\Zendesk;

use WeDevs\ERP\Framework\Models\People;
use WeDevs\ERP\CRM\Contact;

class User {

    /**
     * Constructor function
     */

    function __construct() {
        $this->get_contact();
    }

    /**
     * Get contact
     *
     * @return void
     */
    public function get_contact() {
        $customers = $this->get_zendesk_customer();

        if ( is_wp_error( $customers ) ) {
            wp_redirect( admin_url( 'admin.php?' . $_SERVER['QUERY_STRING'] . '&foo=bar' ) );
            return;
        }

        if ( ! $customers ) {
            return;
        }

        foreach ( $customers->users as $customer ) {
            $contact    = People::where( 'email', $customer->email )->first();

            if ( !$contact && function_exists( 'erp_insert_people' ) ) {
                $args   =   array(
                    'first_name'    =>   $customer->name,
                    'email'         =>   $customer->email,
                    'phone'         =>   $customer->phone
                );

                $id = $customer->id;
                $contact = $this->insert_user( $args, $id );

                if ( ! $contact instanceof Contact ) {
                    $contact = new Contact( $contact->id );
                }
            }
        }
    }

    /**
     * Insert contact
     *
     * @param  array $args
     * @param  integer $id
     * @return void
     */
    public function insert_user( $args, $id ) {
        $args   = wp_parse_args( $args, [
            'first_name'    => '',
            'last_name'     => '',
            'email'         => '',
            'phone'         => '',
            'country'       => '',
            'website'       => '',
            'type'          => 'contact'
        ] );

        $people     = erp_insert_people( $args, true );

        if ( is_wp_error( $people ) ) {
            return fasle;
        }

        $contact        = new Contact( absint( $people->id ), 'contact' );
        $life_stage     = 'customer';
        $contact_owner  = erp_crm_get_default_contact_owner();

        if ( !$people->existing ) {
            $contact->update_meta( 'life_stage', $life_stage );
            $contact->update_meta( 'source', 'optin_form' );
            $contact->update_meta( 'contact_owner', $contact_owner );
            $contact->update_meta( 'zendesk_user_id', $id );
        } else {
            if ( !$contact->get_life_stage() ) {
                $contact->update_meta( 'life_stage', $life_stage );
            }

            if ( !$contact->get_source() ) {
                $contact->update_meta( 'source', 'optin_form' );
            }

            if ( !$contact->get_contact_owner() ) {
                $contact->update_meta( 'contact_owner', $contact_owner );
            }
        }

        return $contact;
    }


    /**
     * Get zendesk customer
     *
     * @return array
     */
    public function get_zendesk_customer() {
        $subdomain          = erp_get_option( 'zendesk_subdomain', 'erp_settings_erp-crm_zendesk_integration' );
        $zendesk_email      = erp_get_option( 'zendesk_login_email', 'erp_settings_erp-crm_zendesk_integration' );
        $zendesk_password   = erp_get_option( 'zendesk_password', 'erp_settings_erp-crm_zendesk_integration' );
        $url                = 'https://' . $subdomain . '/api/v2/users.json?role[]=admin&role[]=end-user';

        if ( empty( $subdomain ) || empty( $zendesk_email ) || empty( $zendesk_password ) ) {
            return;
        }

        $args = array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode( $zendesk_email . ':' . $zendesk_password )
            )
        );

        $response = wp_remote_get( $url, $args );

        if ( $response['response']['code'] == 401 ) {
            return new \WP_Error('zendesk_err', 'Error 401');
        } elseif( $response['response']['code'] == 404 ) {
            return new \WP_Error('zendesk_err', 'Error 401');
        }

        $customers = array();

        if ( $response['body'] ) {
            $customers = json_decode( $response['body'] );
        }

        return $customers;
    }
}
