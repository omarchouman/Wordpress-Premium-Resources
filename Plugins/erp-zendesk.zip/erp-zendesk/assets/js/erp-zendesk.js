( function( $ ) {
    var app = {};


    app.init = function() {
        var contact_id = null;

        if ( erpZendesk.contact_id !== null && erpZendesk.contact_id !== undefined ) {
            contact_id = erpZendesk.contact_id;

            var data = {
                action: 'erp_zendesk_activity',
                contact_id: contact_id,
                nonce: erpZendesk.nonce,
            };

            $.post( erpZendesk.ajaxurl, data, function( res ){
                $( '.erp-zendesk-activity .inside' ).removeClass('loading');
                var contentArea = $( '.erp-zendesk-activity .inside' );

                if ( res.success ) {
                    contentArea.html('<p>'+res.data.message+'</p>');
                } else {
                    if ( res.data.message ) {
                        contentArea.html('<p>'+res.data.message+'</p>');
                    }
                }
            } );
        }
    }

    $(document).ready(app.init);
    return app;
})( jQuery );