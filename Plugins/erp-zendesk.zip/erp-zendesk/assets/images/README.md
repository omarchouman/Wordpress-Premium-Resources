# Project Images

Only images in use by the project should be placed in this folder.  Wherever possible, combine multiple small images into sprites to be used by CSS. Original (non-sprite) images should be placed in the `/src` subdirectory.